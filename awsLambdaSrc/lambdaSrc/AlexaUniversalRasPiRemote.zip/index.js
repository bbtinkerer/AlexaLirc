'use strict'

var AWS = require('aws-sdk');
var MyDevices = require('./lib/MyDevices');
var AlexaResponsesUtil = require('./lib/AlexaResponsesUtil.js');

var mqttTopic = 'remote/';

var getAwsIotParams = function(topic, qos, message) {
  return {
    topic: topic,
    qos: qos,
    payload: new Buffer(message) || 'STRING_VALUE'
  };
};

var publishToAwsIot = function(event, message, qos, response, callback) {
  console.log('DEBUG - publishToAwsIot start');
  var endpointId = event.directive.endpoint.endpointId;
  var topic = mqttTopic + endpointId;
  var params = {
    topic: topic,
    qos: qos,
    payload: new Buffer(message) || 'STRING_VALUE'
  };
  var iotData = new AWS.IotData({ endpoint: event.directive.endpoint.cookie.iotEndpoint });
  iotData.publish(params, (err, data) => {
    if (err) console.log(err, err.stack)
    else {
      console.log("DEBUG - publishToAwsIot - iotData.publish: ", data);
      console.log("DEBUG - handleStepSpeaker - response: ", response);
      callback(null, response);
    }
  });
  console.log('DEBUG - publishToAwsIot end');
};

var handleDiscovery = function(event, context, callback) {
  console.log('DEBUG - handleDiscovery start');
  var devices = new MyDevices();
  var response = devices.getAlexaDiscoveryResponse();
  console.log(response);
  callback(null, response);
  console.log('DEBUG - handleDiscovery end');
};

var handlePowerController = function(event, context, callback, name) {
  console.log('DEBUG - handlePowerController start');
  var aru = new AlexaResponsesUtil(event);
  var onOff = (name === 'TurnOn' ? 'ON' : 'OFF');
  var response = aru.getPowerControllerResponse(onOff);
  publishToAwsIot(event, name, 0, response, callback);
  console.log('DEBUG - handlePowerController end');
};

var handleChannelController = function(event, context, callback, name) {
  console.log('DEBUG - handleChannelController start');
  var aru = new AlexaResponsesUtil(event);
  var response = aru.getChannelControllerResponse();
  
  var message = name + ' ';
  var channel;

  if (name === 'ChangeChannel') {
    channel = event.directive.payload.channel.number;
    if (channel) {
      message += channel;
    }
  }
  else if (name === 'SkipChannels') {
    var channelCount = parseInt(event.directive.payload.channelCount);
    message += (channelCount > 0 ? 'UP' : 'DOWN');
  }

  if (name === 'ChangeChannel' && !channel) {
    response.event.header.name = "ErrorResponse";
    response.event.payload = {
      "type": "INVALID_VALUE",
      "message": "Channel names are not supported"

    }
    console.log('ERROR:', JSON.stringify(response));
    callback(response);
  }
  else {
    publishToAwsIot(event, message, 0, response, callback);
  }
  console.log('DEBUG - handleChannelController end');
};

var handleInputController = function(event, context, callback, name) {
  console.log('DEBUG - handleInputController start');
  var aru = new AlexaResponsesUtil(event);
  var response = aru.getInputControllerResponse(event.directive.payload.input);
  publishToAwsIot(event, name, 0, response, callback);
  console.log('DEBUG - handleInputController end');
};

var handleStepSpeaker = function(event, context, callback, name) {
  console.log('DEBUG - handleStepSpeaker start');
  var aru = new AlexaResponsesUtil(event);
  var response = aru.getStepSpeakerResponse();
  var message = name;

  if (name === 'AdjustVolume') {
    var volumeSteps = parseInt(event.directive.payload.volumeSteps);
    message += ' ' + (volumeSteps > 0 ? "UP" : "DOWN");
  }
  
  publishToAwsIot(event, message, 0, response, callback); 
  console.log('DEBUG - handleStepSpeaker end');
};

exports.handler = (event, context, callback) => {
  console.log('DEBUG - exports.handler start - (event): ', JSON.stringify(event));

  var header = event.directive.header;
  var namespace = header.namespace;
  var name = header.name;

  if (namespace === 'Alexa.Discovery' && name === 'Discover') {
    console.log('DEBUG - exports.handler: Alexa.Discovery event');
    handleDiscovery(event, context, callback);
  }
  else if (namespace === 'Alexa.PowerController' && (name === 'TurnOn' || name === 'TurnOff')) {
    console.log('DEBUG - exports.handler: Alexa.PowerController event', name);
    handlePowerController(event, context, callback, name);
  }
  else if (namespace === 'Alexa.ChannelController' && (name === 'ChangeChannel' || name === 'SkipChannels')) {
    console.log('DEBUG - exports.handler: Alexa.ChannelController event', name);
    handleChannelController(event, context, callback, name);
  }
  else if (namespace === 'Alexa.InputController' && name === 'SelectInput') {
    console.log('DEBUG - exports.handler: Alexa.InputController event', name);
    handleInputController(event, context, callback, name);
  }
  else if (namespace === 'Alexa.StepSpeaker' && (name === 'AdjustVolume' || name === 'SetMute')) {
    console.log('DEBUG - exports.handler: Alexa.StepSpeaker event', name);
    handleStepSpeaker(event, context, callback, name);
  }

  console.log('DEBUG - exports.handler end');
};
